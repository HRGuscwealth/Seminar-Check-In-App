# U.S. Capital Wealth Design System

**Company description:** U.S. Capital Wealth // HRG Wealth Management (Houston Retirement Group) — boutique wealth management practice serving ExxonMobil pre-retirees and energy industry professionals in Houston.

A working brand kit for **U.S. Capital Wealth** and its boutique practice **HRG Wealth Management (Houston Retirement Group)** — a wealth management firm serving ExxonMobil pre-retirees and energy industry professionals out of Houston.

This folder is the canonical source of truth for visual identity across every output the practice produces: YouTube video graphics (1920×1080), HTML email newsletters, LinkedIn posts, client-facing sell sheets, and slide decks.

---

## Source materials

| Source | What it gave us |
| --- | --- |
| `uploads/USCW_Brand Guidelines_09.29.25.pdf` | The 8-page brand standards: logo lockups, type, color, photography rules, marquee graphic element, example sell-sheet and website. |
| `uploads/U.S. Capital Wealth Overview - HRG Wealth Management.pdf` | 22-page firm overview: history, services, locations, leadership, recognitions. Source for the "Firm at a glance" section below. |
| User-supplied logo files | Official PNGs for primary, gold, HRG sub-brand, shield-only and Zoom variants. |
| Color list provided in prompt | Confirms `#002a47` (navy), `#004975` (medium blue), `#0f465a` (teal), `#d2aa7e` (gold), `#f0e8d8` (cream). |

## Firm at a glance

| | |
| --- | --- |
| **Tagline** | *Boutique Wealth Management Powered by Institutional Insight.* |
| **AUM** | $11B (09.30.25) |
| **Founded** | 2010, in Houston (as U.S. Capital Advisors) |
| **Merger** | 2021 with Legacy One Financial Advisors → U.S. Capital Wealth |
| **Platform** | 2024 — joined Arax Investment Partners (RedBird Capital–backed) |
| **Team** | 45+ advisory teams · 90+ central service staff |
| **Offices** | Houston HQ · Houston Medical Center · Dallas · Austin · Georgetown TX · New York NY · Andover MA · Coral Gables FL |
| **Recognition (2025)** | USA Today Best Financial Advisory Firms · Barron's Top 100 RIA · AdvizorPro #1 Independent RIA in Houston |

### Three brand pillars
1. **Boutique-Level Service** — high-touch, personalized financial guidance focused on the client's needs.
2. **Institutional-Grade Solutions** — access to sophisticated investment opportunities, wealth strategies, and resources.
3. **Independence You Can Trust** — fiduciary first; client's best interests come first.

### Who the firm serves
- High-Net-Worth investors & families
- Business owners & entrepreneurs
- Specialized sector professionals (energy, healthcare, etc.)

### HRG Wealth Management (sub-brand)
The Houston Retirement Group is the practice within U.S. Capital Wealth led by Christian C. Bauman, Thomas C. Carman, and Scott M. Selzer — all Senior Managing Directors with deep oil-and-gas-industry retirement and business-exit experience. Same identity, color, type, and marquee as the parent firm; copy is tuned for an audience of pre-retirees in the Energy Corridor.

> ✅ **Official logo artwork supplied.** Transparent PNGs (primary navy, gold, HRG sub-brand) live in `assets/logos/`. If a vector (`.ai` / `.svg` / `.eps`) version is available, drop it in alongside the PNGs — outputs will use it automatically.

---

## Index — what lives where

```
/                                  ← root manifest
├── README.md                       (you are here)
├── SKILL.md                        Agent-Skills entrypoint
├── colors_and_type.css             ⭐ brand tokens + base styles
├── long_form.css                   ⭐ long-form document components (pages, tables, callouts)
├── assets/
│   ├── logos/                      official PNGs (primary navy, gold, HRG, shield, Zoom)
│   ├── marquee/                    the gold ·★· rule (SVG)
│   ├── textures/                   diamond-quilt navy + black
│   ├── imagery/                    licensed stock samples from brand book
│   └── examples/                   website + sell-sheet reference images
├── fonts/                          (empty — using Google Fonts CDN; see typography section)
├── preview/                        design-system tab cards (rendered foundations)
├── slides/                         16:9 sample slides for YouTube/decks
└── ui_kits/
    ├── newsletter/                 HTML email — header, hero, articles, footer
    ├── sell_sheet/                 letter-size client-facing sell sheet
    ├── long_form_guide/            multi-page editorial guide (Financial Planning Guide style)
    └── tax_reference/              dense table-driven handbook (Tax Handbook style)
```

The Design System tab of this project pulls everything in `preview/`, plus the slides and UI kits.

---

## Brand at a glance

U.S. Capital Wealth presents as a **boutique partner with institutional grade** — quiet, monied, and serious. The visual language is print-rooted: classical serif typography, a navy + gold heraldic palette, generous white space, photographic realism over illustration, sharp 90° corners, and the signature **gold marquee rule** as section separator. Think *private bank annual report* more than *fintech startup*.

The brand sub-line **HRG Wealth Management** (Houston Retirement Group) is the same identity tuned for an audience of pre-retiree ExxonMobil professionals — same type, color, and marquee, with copy that talks about *retirement income*, *qualified-plan rollovers*, *pension elections*, and *the Energy Corridor*.

---

## Content fundamentals

### Voice
- **Confident, advisory, never pushy.** The firm is a partner, not a salesperson. Copy reads like a fiduciary writing to a peer.
- **Sophistication without jargon vapor.** Real technical terms (1031, DST, ESPP, 72(t), RMD) appear plainly; buzz words (*synergy*, *next-gen*, *cutting-edge*) do not.
- **Quietly aspirational.** The PDF describes the visual mood as *"discretion, sophistication, and clarity"* — the copy should match. State what is true; let the reader supply the awe.

### Person
- **"We" for the firm. "You" for the client.** Default to second-person warmth: *"You've spent thirty years at one company. The next decade looks different."* Avoid "I" unless an advisor is signing a piece personally.
- **First-name signoffs** (`Ben Meadows // Financial Advisor // U.S. Capital Wealth`) using the double-slash divider.
- **Always write the brand name as "U.S. Capital Wealth"** — not "U.S. Capital Wealth Advisors". The longer LLC name is the *legal entity* used inside SEC disclosures and Form ADV filings; the *brand name* across every client-facing surface is the shorter form.

### Casing
- **Sentence case for body copy.** Title Case for slide titles and major section heads.
- **ALL CAPS, tracked** for eyebrow labels, button labels, navigation, and small text dividers (`SUBHEAD`, `TEXT DIVIDER`, `WEALTH MANAGEMENT`).
- **Cormorant Garamond is used in mixed case** for headlines — never all caps.

### Punctuation & dividers
- The **double-slash divider** is canonical: `Name // Title // Firm`, `Office: ###.###.#### // Fax: ###.###.####`. Two spaces on each side of the `//`. Use `<span class="dbl-slash"></span>` or paste `  //  ` literally.
- The **gold marquee** (`──── ·★· ────`) separates headline from subhead, or anchors a section opener. Always leave breathing room above and below.

### What you'll see in approved copy
- *"Boutique wealth management powered by institutional insight."* — the elevator pitch
- *"Why choose U.S. Capital Wealth?"* — section-header phrasing
- *"Your trusted partner for sophisticated wealth solutions."*
- *"Reimagine your real estate strategy. Start your 1031 Exchange with confidence."*
- *"Speak with a USCW Wealth Advisor today."*
- *Subheads frame benefits as outcomes:* "Unlock more listings", "Keep deals alive", "Boost your value proposition", "Serve the retirement-minded investor".
- *In long-form guides:* "The new year provides a great opportunity to assess areas which may require updates." Calm, second-person, slightly formal — never breathless.

### Long-form / educational pieces (Tax Handbook, Planning Guide)
- **Section structure:** divider page (blueprint cityscape + Cormorant title) → topical section opener (gold pictogram icon + headline) → body with tables and short paragraphs → footer disclosure on every page.
- **Title case** for major heads ("Quick Takes for the New Year", "Strategic Solutions for Business Owners"). Sentence case for sub-heads.
- **Citation style:** numbered superscript footnotes citing primary sources at the foot of the page (`Source: Revenue Procedure 2025-32.` / `Source: IRS – "…"`).
- **Disclosures** — short topical disclosures sit under tables; the long-form legal disclosure runs at the bottom of every page in 9-px gray.

### What to avoid
- ❌ Emoji of any kind in client-facing material.
- ❌ Exclamation points outside event invitations.
- ❌ Hype ("revolutionary", "game-changing", "AI-powered").
- ❌ Casual abbreviations ("we'll", "let's") in formal pieces — fine in YouTube scripts and social.
- ❌ Promises about outcomes. Wealth/tax language must be conditional: *"may help"*, *"in appropriate situations"*, *"subject to your tax situation"*. The sell-sheet example uses these guardrails consistently.

---

## Visual foundations

### Colors
Two pillars: deep **navy** (authority, stability) and warm **gold** (heritage, value). Everything else is neutral support. Full token set lives in `colors_and_type.css`.

| Role | Token | Hex | Use |
| --- | --- | --- | --- |
| Primary | `--uscw-navy` | `#002a47` | Dominant brand color. Headlines on light, full backgrounds, primary buttons. |
| Mid blue | `--uscw-blue-medium` | `#004975` | Top of the brand gradient; hover state for navy buttons. |
| Teal | `--uscw-teal` | `#0f465a` | Subtle dark backgrounds, eyebrow color on light. |
| Link blue | `--uscw-link-blue` | `#0076be` | **Hyperlinks only.** Per guidelines: secondary, used sparingly. |
| Gold | `--uscw-gold` | `#d2aa7e` | Marquee rule, gold logo, accent text on dark, CTA highlights. |
| Cream | `--uscw-gold-light` | `#f0e8d8` | Quiet paper backgrounds, callout panels. |
| Light blue/green | `--uscw-light-blue-green` | `#cad5d4` | Tertiary surface, sparingly. |
| Grays | `#282828 / #505050 / #878787 / #c1c2c0 / #dedfdd / #efefee` | | Body copy hierarchy, dividers, disabled states. |
| Gradient | `--uscw-gradient-dark` | `#004975 → #0a1f2c` | Hero/end-card backgrounds when full diamond texture is too heavy. |

**Color vibe of imagery:** cool-neutral, slight blue cast, natural lighting. Never heavily warm/orange unless it's an energy-industry scene (pumpjacks at sunset is fine). Never desaturated to grayscale unless intentional editorial.

### Type
- **Display:** Cormorant Garamond — Light (300) and Regular (400) for headlines and titles. Used mixed-case, never all caps.
- **Sans:** Avenir is the spec font. We substitute **Nunito Sans** as the closest free Google Fonts match. Drop a real Avenir Next Pro into `fonts/` and replace `'Nunito Sans'` in `colors_and_type.css` if licensed. *(Other reasonable substitutes: Mulish, Hanken Grotesk.)*
- **Body & subheads:** Avenir Light / Regular at 16–18 px; 14 px for captions, 11 px for disclosures.

**Hierarchy in practice (slide / sell sheet):**
1. Eyebrow — 13 px sans, tracked 0.32em, uppercase, teal or gold.
2. Headline — Cormorant 44–88 px, light weight, mixed case.
3. **Gold marquee rule** (the section signature).
4. Subhead — Cormorant 22–28 px or Avenir 18–20 px medium.
5. Body — Avenir 16–17 px, line-height 1.55, max 68ch.
6. Text divider — `Name // Title // Firm` in tracked sans, 14 px.

### Spacing
Even, generous, print-rooted: `4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96 / 128 px`. The signature move is *more whitespace than feels necessary, then a little more* — sell sheets and slides leave the marquee rule and headline floating in a sea of negative space.

### Backgrounds
- **Solid navy** with diamond-quilt texture (`assets/textures/diamond-quilt-navy.png`) — the "hero" surface. Use for sell-sheet headers, slide title cards, YouTube end cards.
- **Solid black diamond-quilt** — premium dark variant.
- **Architectural blueprint imagery** — the **Houston blueprint cityscape** (`assets/textures/blueprint-cityscape.png`) is screened back over navy as section divider in long-form guides and on the live website hero.
- **Cream `#f0e8d8`** — quiet callout/notice panels (used in the sell-sheet CTA strip).
- **Plain white** — default body surface for newsletters and long-form copy.
- **No gradients on text. No bluish-purple gradients ever.**

### Borders, corners, shadows
- **Corners are sharp (0 px radius).** This is not negotiable for headline panels, sell-sheet blocks, cards, and buttons. Pills and avatars may use full-radius; that's it.
- **Borders:** 1 px hairlines in `#e6e1d6` (cream-tinted) on light surfaces; `rgba(255,255,255,0.12)` on dark. Avoid drop-shadow chrome on flat blocks.
- **Shadows are reserved for "lifted paper" effects** (sell sheet on a desk, polaroid). When used: long, soft, blue-tinted (`0 16px 48px rgba(0,24,41,0.18)`).
- **No inner shadows. No glassmorphism. No backdrop-blur** for client deliverables.

### Hover & press states
- **Buttons:** hover lightens navy → medium blue (`#004975`); press darkens to `#001a2d`. Gold buttons hover to `#c69c6e`. Transition `160ms ease`.
- **Links:** underline appears on hover (1 px border-bottom). Color unchanged.
- **Cards / list rows:** hover lifts faintly (`shadow-1`) and shifts background to `--uscw-gray-100`. Press: no shrink.
- **Ghost / outline:** background fills to the border color on hover.

### Iconography, marks, ornaments
- **The gold marquee rule with center star** is the brand's signature ornament — between headline and subhead, or as a section separator. Always leave breathing room above and below.
- **The double-slash divider** (` // `) is the text equivalent of the marquee — used in attribution lines.
- The **shield emblem** (three classical columns under a banded capital) carries the heraldic, US-Capitol-evoking feel.

### Animation
Print sensibility, not interaction-heavy. When motion is used:
- **Fades, never bounces.** Easing: `cubic-bezier(0.22, 0.61, 0.36, 1)` (gentle ease-out) at 240–320 ms.
- **Reveal on scroll** for headlines and the marquee rule (rule scales out from center, headline fades up 12 px).
- **Crossfades** between video b-roll, never hard cuts on title cards.
- **No parallax, no kinetic typography, no springy bounces.**

### Layout rules
- Hero blocks: navy diamond-quilt with gold logo top-left, optional menu top-right.
- Section opener: eyebrow → headline → gold marquee → subhead — vertically centered with generous padding (96–128 px top/bottom).
- Sell sheet: navy "flag" header with diamond quilt at top, brown-leather lower band, content on cream/white center.
- Body content max-width ~720 px (`68ch`) for readability.

### Transparency & blur
- Used **only** when an image needs a navy or gold protection wash so text reads on top (e.g. navy with `mix-blend-multiply` or a 60 % navy overlay). Never used for chrome / cards.

---

## Iconography

The firm **does** use icons in long-form documents (the *2026 Tax Handbook*, the *2026 Financial Planning Guide*, sell sheets). On the website and in slide graphics, icons are used sparingly — type + marquee + photography do most of the work.

### The official icon style
Flat, single-color pictograms in **brand gold (`#d2aa7e`)**, drawn ~150–260 px square, used as section markers above a headline (never as decorative chrome inside body copy). Subjects are concrete and topical: a family group, two figures at a meeting table, a head with gears (planning), a money bill, a protective shield, a padlock, etc.

A starter set is in `assets/icons/`:
- `family.png` — four-figure family group
- `meeting.png` — two figures at a table
- `thinking-head.png` — head with gears (planning)
- `estate.png` — family-at-home (estate planning)
- `shield-protect.png` — protective shield (risk management)
- `money.png` — stack of bills (income / cash flow)
- `cyber-lock.png` — padlock (security / fraud protection)
- `handshake.png` — retirement / advisory
- `people.png` — group / community

### When to use what
- **Long-form guides, sell sheets, handouts:** the gold pictogram icons above. One per section, sized 56–80 px in print.
- **Status / data-callout icons (✓ / ✗):** a flat blue square + glyph at link-blue `#0076be`. Used only inside scorecards (e.g. *Up to date / Action needed*).
- **Small UI icons** (menu, search, arrow, social): Lucide at 1.5 px stroke, `currentColor`. *Flagged: this is our pick, not a brand spec — swap if the firm prefers another set.*
  ```html
  <script src="https://unpkg.com/lucide@latest"></script>
  <i data-lucide="menu" stroke-width="1.5"></i>
  ```

### Hard rules
- **No emoji** in any client-facing piece. None.
- **No multi-color icons.** Gold pictograms on light, gold on dark, blue glyphs only in checkmark/x status indicators.
- **No 3D, gradient, or glossy icons.**
- **Never use the icon as decoration.** If a section doesn't have a clear topical icon, skip it — the marquee rule and a Cormorant headline are enough on their own.

## Surfaces & motifs

### Section divider — blueprint cityscape
The firm uses a **wireframe Houston cityscape** screened back on navy (`assets/textures/blueprint-cityscape.png`) as the section-divider background in long-form documents. Use it for divider pages, hero strips, and YouTube section openers when an architectural mood is appropriate. Always pair with a centered Cormorant headline and gold eyebrow.

### Available logo files
- `assets/logos/uscw-logo-primary-blue.png` — full lockup, navy (use on light backgrounds)
- `assets/logos/uscw-logo-gold.png` — full lockup, gold (use on dark backgrounds only)
- `assets/logos/uscw-shield-blue.png` / `uscw-shield-gold.png` — shield-only bug (cropped from the full lockup)
- `assets/logos/uscw-zoom-lockup-navy.png` — compact horizontal lockup on navy plate (use for Zoom backgrounds, video lower-thirds)
- `assets/logos/hrg-wealth-management-blue.png` — HRG full sub-brand lockup, navy
- `assets/logos/hrg-wealth-management-gold.png` — HRG full sub-brand lockup, gold
- `assets/marquee/marquee-gold.svg` / `marquee-navy.svg` — the marquee rule (vector, recreated)

> The marquee SVGs are recreations. Replace with vector source if/when available.

---

## Imagery

The PDF specifies Adobe Stock as the preferred source. Eight reference shots from the guideline book live in `assets/imagery/`:

| File | Subject |
| --- | --- |
| `family-courtyard-dinner.png` | Multi-generational family, candid dinner — Houston aspirational lifestyle. |
| `family-beach-multigenerational.png` | Three generations on beach — retirement / legacy planning. |
| `family-sunset-pointing.png` | Father + daughter + mother — future-facing, warm light. |
| `yacht-aerial-ocean.png` | Aerial yacht bow — UHNW lifestyle. |
| `oil-pumpjacks-sunset.png` | Energy industry — speaks directly to ExxonMobil audience. |
| `wireframe-city-tactile.png` | Architectural wireframe — institutional / advisory. |
| `financial-magnifier.png` | Charts under magnifier — research, due diligence. |
| `financial-data-stylus.png` | Stylus on data dashboard — capital markets. |
| `institutional-bank-hands.png` | Bank illustration in hands — fiduciary care. |

**Rules (from PDF page 4–5):**
- **Window-into-the-life perspective.** Subjects engaged in real activity, not looking at camera.
- **Subject hierarchy:** *Places → People → Things.*
- **Cool-neutral palette, natural light**, understated luxury.
- **No alcohol, tobacco, firearms, provocative, or culturally insensitive subjects.**
- **Inclusive representation** across age, ethnicity, gender — matches the HNW/UHNW clients served.
- **Min 1920 px for web, 300 dpi for print.**

---

## Long-form documents (guides, handbooks, reports)

The firm produces a lot of multi-page editorial in two distinct shapes. Both are in `ui_kits/` and both consume `long_form.css` on top of `colors_and_type.css`:

| Kit | When to use | Key components |
| --- | --- | --- |
| **`long_form_guide/`** | Editorial client guides with chapters, mixed content, narrative copy. Examples: the annual *Financial Planning Guide*, *Estate Planning Brief*, *Retirement Roadmap*. | `lf-cover`, `lf-divider`, `lf-header`, `lf-footer`, `lf-toc`, `qt-grid` (Quick Takes), `scorecard`, `lf-callout`, `lf-footnotes`. |
| **`tax_reference/`** | Dense, table-driven reference cards. Examples: the annual *Tax Handbook*, *RMD reference*, *Contribution-limits one-pager*. | `lf-disclaimer` banner, `lf-section-title`, `lf-subsection-label` (ultra-tracked uppercase), `lf-source`, `lf-table`. |

### Rules that apply to all long-form output
- **Cover & section dividers** are the only places the gold marquee belongs. Content pages don't repeat it.
- **Every content page has chrome:** `lf-header` (shield + chapter title + page number) at top, `lf-footer` (URL + tagline + page number) at bottom.
- **Tracked subsection labels** (`A M T · E X E M P T I O N`) are a brand signature — use `letter-spacing: 0.6em` and the gold under-rule.
- **Every reference subsection cites a source.** Italic, 10 px, gray. Skip it and the piece reads like a blog post, not a brief.
- **Footnotes use the gold numeral marker** (`<span class="n">1</span>`) at 9 px / 1.55 line-height.
- **Status dots** in the scorecard come from a tight palette: green `#5f8a52`, gold (brand), terracotta `#b45a3c`, gray. Avoid pure red — it's outside the brand and adds urgency the firm doesn't want.

---

## How to use this system

```html
<!-- 1. Link the foundation -->
<link rel="stylesheet" href="colors_and_type.css">

<!-- 2. Drop in a hero -->
<section class="surface-dark tx-diamond-navy">
  <span class="eyebrow eyebrow--gold">Boutique Wealth Management</span>
  <h1 class="display">Powered by institutional insight.</h1>
  <span class="marquee"><span class="marquee__mark">
    <span class="marquee__star"></span>
  </span></span>
  <p>Based in Houston with offices nationwide…</p>
  <button class="btn btn--gold">Speak With an Advisor</button>
</section>

<!-- 3. Sign off -->
<p class="txt-divider">
  Ben Meadows <span class="sep">//</span> Financial Advisor
  <span class="sep">//</span> U.S. Capital Wealth
</p>
```

See the cards in `preview/`, sample slides in `slides/`, and full layouts in `ui_kits/`.

---

## Caveats / known gaps

- **Logo art is official PNG.** Vector (.svg/.ai/.eps) would be ideal for crisp print and large slide use — drop into `assets/logos/` if available.
- **Avenir is substituted with Nunito Sans** via Google Fonts. If the firm has Avenir Next Pro licensed, drop the `.woff2` into `fonts/` and swap the family name.
- **No real photo library** beyond what's in the PDF — production work should pull from Adobe Stock per the guidelines.
- **No bespoke icon set** exists; we recommend Lucide as a neutral default and flag this for review.
