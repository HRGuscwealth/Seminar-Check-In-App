/* @ds-bundle: {"format":3,"namespace":"USCapitalWealthDesignSystem_019e2c","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.USCapitalWealthDesignSystem_019e2c = window.USCapitalWealthDesignSystem_019e2c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
